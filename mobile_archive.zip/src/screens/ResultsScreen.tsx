import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity } from 'react-native';

export default function ResultsScreen({ route, navigation }: any) {
  // Parsing the YOLO Detection Response
  const { scanData, baseUrl } = route.params || {};

  if (!scanData) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>No scan data available.</Text>
        <TouchableOpacity style={styles.button} onPress={() => navigation.goBack()}>
          <Text style={styles.buttonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      {/* 1. Analyzed Image */}
      {scanData.image_url ? (
        <Image source={{ uri: scanData.image_url }} style={styles.image} />
      ) : (
        <View style={styles.placeholderImage}>
            <Text style={{color: '#EF4444'}}>No Image Available</Text>
        </View>
      )}

      {/* 2. Verdict Headline */}
      <View style={[styles.headerBlock, { borderBottomColor: scanData.status === 'modified' ? '#EF4444' : '#10B981' }]}>
        <Text style={styles.title}>AI Analysis Result</Text>
        <Text style={[styles.statusText, { color: scanData.status === 'modified' ? '#EF4444' : '#10B981' }]}>
          VERDICT: {scanData.status?.toUpperCase()}
        </Text>
        <Text style={styles.subtitle}>
          Confidence: {(scanData.binary_confidence * 100).toFixed(1)}%
        </Text>
      </View>

      {/* 3. Expert XAI Evaluation Cards */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>EXPERT COMPLIANCE REPORT</Text>
        {scanData.detections?.length > 0 ? (
          scanData.detections.map((det: any, index: number) => (
            <View key={index} style={styles.card}>
              <View style={styles.cardHeader}>
                <Text style={styles.cardTitle}>{det.explanation?.violation || det.component_name.replace('_', ' ').toUpperCase()}</Text>
                <Text style={[styles.severityTag, styles[det.explanation?.severity as keyof typeof styles || 'medium']]}>
                  {det.explanation?.severity?.toUpperCase() || 'MODERATE'}
                </Text>
              </View>

              <Text style={styles.description}>{det.explanation?.description}</Text>

              {/* AI VISUAL JUSTIFICATION (Grad-CAM) */}
              {det.heatmap && (
                <View style={styles.heatmapContainer}>
                  <Text style={styles.heatmapLabel}>AI FOCUS MAP (GRAD-CAM)</Text>
                  <Image 
                    source={{ uri: `data:image/png;base64,${det.heatmap}` }} 
                    style={styles.heatmapImage} 
                  />
                  <Text style={styles.heatmapCaption}>Red zones indicate areas contributing to mod detection.</Text>
                </View>
              )}

              <View style={styles.legalBox}>
                <Text style={styles.legalLabel}>LEGAL REASONING (CMVR/RTO)</Text>
                <Text style={styles.legalText}>{det.explanation?.why_illegal}</Text>
              </View>

              <View style={styles.metaRow}>
                <Text style={styles.metaText}>Location: {det.explanation?.location}</Text>
                <Text style={styles.metaText}>{det.explanation?.confidence}</Text>
              </View>
            </View>
          ))
        ) : (
          <View style={styles.emptyBox}>
            <Text style={styles.emptyText}>No localized violations identified.</Text>
          </View>
        )}
      </View>

      {/* 4. Action */}
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Camera')}>
        <Text style={styles.buttonText}>Scan Another Vehicle</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0F19' },
  center: { flex: 1, backgroundColor: '#0B0F19', justifyContent: 'center', alignItems: 'center' },
  errorText: { color: '#EF4444', fontSize: 18, marginBottom: 20 },
  image: { width: '100%', height: 250, resizeMode: 'cover' },
  placeholderImage: { width: '100%', height: 250, backgroundColor: '#1E293B', justifyContent: 'center', alignItems: 'center'},
  headerBlock: { padding: 20, borderBottomWidth: 4 },
  title: { fontSize: 20, fontWeight: '900', color: '#FFFFFF', letterSpacing: 0.5 },
  statusText: { fontSize: 28, fontWeight: '900', marginTop: 8 },
  subtitle: { fontSize: 14, color: '#9CA3AF', marginTop: 4 },
  section: { padding: 20 },
  sectionTitle: { color: '#3B82F6', fontWeight: 'bold', fontSize: 12, marginBottom: 15, letterSpacing: 1 },
  card: { backgroundColor: '#1E293B', borderRadius: 16, padding: 16, marginBottom: 16, borderLeftWidth: 4, borderLeftColor: '#3B82F6' },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  cardTitle: { fontSize: 17, fontVariant: ['small-caps'], fontWeight: 'bold', color: '#F8FAFC', flex: 1 },
  severityTag: { fontSize: 10, fontWeight: '900', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 4, overflow: 'hidden' },
  critical: { backgroundColor: '#EF4444', color: 'white' },
  high: { backgroundColor: '#F97316', color: 'white' },
  medium: { backgroundColor: '#FCD34D', color: '#1E293B' },
  low: { backgroundColor: '#3B82F6', color: 'white' },
  description: { color: '#9CA3AF', fontSize: 14, lineHeight: 20, marginBottom: 16 },
  legalBox: { backgroundColor: 'rgba(59, 130, 246, 0.05)', padding: 12, borderRadius: 12, borderWidth: 1, borderColor: 'rgba(59, 130, 246, 0.2)', marginBottom: 12 },
  legalLabel: { color: '#3B82F6', fontSize: 10, fontWeight: 'bold', marginBottom: 4 },
  legalText: { color: '#F1F5F9', fontSize: 13, fontStyle: 'italic' },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.05)', paddingTop: 12 },
  metaText: { color: '#64748B', fontSize: 11 },
  emptyBox: { padding: 40, alignItems: 'center' },
  emptyText: { color: '#64748B', fontStyle: 'italic' },
  button: { marginHorizontal: 20, backgroundColor: '#3B82F6', paddingVertical: 14, borderRadius: 12, alignItems: 'center', marginTop: 10 },
  buttonText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
  
  // Heatmap Styles
  heatmapContainer: { marginBottom: 16, backgroundColor: 'rgba(0,0,0,0.2)', padding: 12, borderRadius: 12, borderStyle: 'dashed', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  heatmapLabel: { fontSize: 10, fontWeight: 'bold', color: '#94A3B8', marginBottom: 8, letterSpacing: 0.5 },
  heatmapImage: { width: '100%', height: 160, borderRadius: 8, resizeMode: 'contain', backgroundColor: '#000' },
  heatmapCaption: { fontSize: 10, color: '#64748B', marginTop: 8, fontStyle: 'italic', textAlign: 'center' }
});

import React, { useEffect, useState, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Camera, useCameraDevices } from 'react-native-vision-camera';
import axios from 'axios';

export default function CameraScreen({ navigation }: any) {
  const devices = useCameraDevices();
  const device = devices.back;
  const camera = useRef<Camera>(null);
  
  const [hasPermission, setHasPermission] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    (async () => {
      const status = await Camera.requestCameraPermission();
      setHasPermission(status === 'authorized');
    })();
  }, []);

  const captureAndAnalyze = async () => {
    if (camera.current) {
      try {
        setIsProcessing(true);
        const photo = await camera.current.takePhoto({
          qualityPrioritization: 'speed',
          flash: 'off'
        });

        const formData = new FormData();
        formData.append('file', {
          uri: `file://${photo.path}`,
          name: 'scan.jpg',
          type: 'image/jpeg'
        } as any);

        // Pointing to FastAPI on local emulator bridge.
        const FASTAPI_URL = 'http://10.0.2.2:8000/api/v1/scan/analyze';
        
        console.log(`Sending image to ModAI backend at ${FASTAPI_URL}`);
        
        const response = await axios.post(FASTAPI_URL, formData, {
            headers: { 
              'Content-Type': 'multipart/form-data',
              'Authorization': 'Bearer demo_token'
            }
        });
        
        // Pass to live Results Screen
        navigation.navigate('Results', { 
            scanData: response.data, 
            baseUrl: 'http://10.0.2.2:8000' 
        });
        
        setIsProcessing(false);
      } catch (e: any) {
        console.error("Camera Capture/Analysis Failed", e.message || e);
        setIsProcessing(false);
      }
    }
  };

  if (!hasPermission) return <Text style={{color: 'white', marginTop: 50}}>Initializing Camera Permission...</Text>;
  if (device == null) return <ActivityIndicator size="large" color="#3B82F6" style={{flex: 1, backgroundColor: '#0B0F19'}} />;

  return (
    <View style={styles.container}>
      <Camera
        ref={camera}
        style={StyleSheet.absoluteFill}
        device={device}
        isActive={true}
        photo={true}
      />
      
      {/* HUD Layer */}
      <View style={styles.hudOverlay}>
        <View style={styles.targetBox} />
      </View>

      <TouchableOpacity 
        style={styles.captureButton} 
        onPress={captureAndAnalyze}
        disabled={isProcessing}
      >
        {isProcessing ? <ActivityIndicator color="white" /> : <View style={styles.captureInner} />}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B0F19', justifyContent: 'center' },
  hudOverlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'center', alignItems: 'center' },
  targetBox: { width: 300, height: 400, borderWidth: 2, borderColor: '#3B82F6', borderRadius: 20, backgroundColor: 'rgba(59, 130, 246, 0.1)' },
  captureButton: { position: 'absolute', bottom: 40, alignSelf: 'center', width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(255,255,255,0.3)', justifyContent: 'center', alignItems: 'center' },
  captureInner: { width: 64, height: 64, borderRadius: 32, backgroundColor: 'white' }
});

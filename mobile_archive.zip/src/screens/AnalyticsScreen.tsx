import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Dimensions } from 'react-native';
import { BarChart3, Users, AlertTriangle, ShieldCheck, TrendingUp, Info } from 'lucide-react-native';
import axios from 'axios';

const { width } = Dimensions.get('window');

// API Base URL - Update this to your local network IP for physical device testing
const API_BASE_URL = 'http://localhost:8000/api/v1';

export default function AnalyticsScreen() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/analytics/metrics`);
      setData(response.data);
    } catch (error) {
      console.error('Failed to fetch metrics', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text style={styles.loadingText}>SYNCING ENFORCEMENT DATA...</Text>
      </View>
    );
  }

  if (!data) return null;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Text style={styles.title}>Compliance Intelligence</Text>
        <Text style={styles.subtitle}>Strategic platform oversight</Text>
      </View>

      {/* KPI Section */}
      <View style={styles.kpiGrid}>
        <View style={[styles.kpiCard, { borderLeftColor: '#3B82F6' }]}>
            <Users size={20} color="#3B82F6" />
            <Text style={styles.kpiLabel}>OFFICERS</Text>
            <Text style={styles.kpiValue}>{data.kpis.total_users}</Text>
        </View>
        <View style={[styles.kpiCard, { borderLeftColor: '#8B5CF6' }]}>
            <BarChart3 size={20} color="#8B5CF6" />
            <Text style={styles.kpiLabel}>SCANS</Text>
            <Text style={styles.kpiValue}>{data.kpis.total_scans}</Text>
        </View>
      </View>

      <View style={[styles.kpiCardFull, { borderLeftColor: '#EF4444' }]}>
        <View style={styles.row}>
            <AlertTriangle size={24} color="#EF4444" />
            <View style={styles.ml12}>
                <Text style={styles.kpiLabel}>TOTAL VIOLATIONS</Text>
                <Text style={styles.kpiValueBig}>{data.kpis.total_detections}</Text>
            </View>
        </View>
      </View>

      {/* Severity breakdown */}
      <Text style={styles.sectionTitle}>Severity Pulse</Text>
      <View style={styles.severityGrid}>
        {Object.entries(data.severity_breakdown).map(([level, count]: [string, any]) => {
            const colors: any = {
                critical: '#EF4444',
                high: '#F97316',
                medium: '#EAB308',
                low: '#3B82F6'
            };
            return (
                <View key={level} style={styles.severityItem}>
                    <View style={[styles.dot, { backgroundColor: colors[level] }]} />
                    <Text style={styles.severityLabel}>{level.toUpperCase()}</Text>
                    <Text style={styles.severityCount}>{count}</Text>
                </View>
            );
        })}
      </View>

      {/* Hotspots */}
      <Text style={styles.sectionTitle}>Modification Hotspots</Text>
      <View style={styles.chartContainer}>
        {Object.entries(data.modification_trends).map(([name, count]: [string, any], idx) => {
            const max = Math.max(...Object.values(data.modification_trends) as number[]);
            const progress = (count / max);
            return (
                <View key={name} style={styles.chartRow}>
                    <View style={styles.chartInfo}>
                        <Text style={styles.chartLabel}>{name.replace('_', ' ').toUpperCase()}</Text>
                        <Text style={styles.chartValue}>{count} events</Text>
                    </View>
                    <View style={styles.barBg}>
                        <View style={[styles.barFill, { width: `${progress * 100}%` }]} />
                    </View>
                </View>
            );
        })}
      </View>

      <TouchableOpacity style={styles.exportButton}>
        <Text style={styles.exportText}>EXPORT COMPLIANCE BRIEF</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0B0F19',
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  centered: {
    flex: 1,
    backgroundColor: '#0B0F19',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 15,
    color: '#64748B',
    fontSize: 10,
    fontFamily: 'System',
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  header: {
    marginBottom: 30,
  },
  title: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  subtitle: {
    color: '#64748B',
    fontSize: 14,
    marginTop: 4,
  },
  kpiGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  kpiCard: {
    backgroundColor: '#161B29',
    width: (width - 55) / 2,
    padding: 20,
    borderRadius: 20,
    borderLeftWidth: 4,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  kpiCardFull: {
    backgroundColor: '#161B29',
    width: '100%',
    padding: 25,
    borderRadius: 20,
    borderLeftWidth: 4,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
    marginBottom: 30,
  },
  kpiLabel: {
    color: '#64748B',
    fontSize: 10,
    fontWeight: '900',
    marginTop: 12,
    letterSpacing: 1,
  },
  kpiValue: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '900',
    marginTop: 4,
  },
  kpiValueBig: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: '900',
    marginTop: 2,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ml12: {
    marginLeft: 15,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 20,
    marginTop: 10,
    letterSpacing: -0.5,
  },
  severityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  severityItem: {
    width: (width - 55) / 2,
    backgroundColor: 'rgba(255,255,255,0.03)',
    padding: 15,
    borderRadius: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginBottom: 8,
  },
  severityLabel: {
    color: '#64748B',
    fontSize: 10,
    fontWeight: 'bold',
  },
  severityCount: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
  },
  chartContainer: {
    marginBottom: 30,
  },
  chartRow: {
    marginBottom: 20,
  },
  chartInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  chartLabel: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: 'bold',
  },
  chartValue: {
    color: '#64748B',
    fontSize: 11,
  },
  barBg: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    backgroundColor: '#3B82F6',
    borderRadius: 4,
  },
  exportButton: {
    backgroundColor: '#3B82F6',
    padding: 18,
    borderRadius: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  exportText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1,
  }
});

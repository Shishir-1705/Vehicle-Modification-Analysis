import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { BrainCircuit, BarChart3 } from 'lucide-react-native';

import CameraScreen from './src/screens/CameraScreen';
import ResultsScreen from './src/screens/ResultsScreen';
import AnalyticsScreen from './src/screens/AnalyticsScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function ScannerStack() {
  return (
    <Stack.Navigator 
      initialRouteName="Camera"
      screenOptions={{
        headerStyle: { backgroundColor: '#0B0F19' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
        headerShadowVisible: false
      }}
    >
      <Stack.Screen 
        name="Camera" 
        component={CameraScreen} 
        options={{ title: 'ModAI Scanner' }} 
      />
      <Stack.Screen 
        name="Results" 
        component={ResultsScreen} 
        options={{ title: 'Analysis Report' }} 
      />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarStyle: {
            backgroundColor: '#111827',
            borderTopColor: 'rgba(255,255,255,0.05)',
            height: 90,
            paddingBottom: 30,
            paddingTop: 10,
          },
          tabBarActiveTintColor: '#3B82F6',
          tabBarInactiveTintColor: '#64748B',
          tabBarLabelStyle: {
            fontSize: 10,
            fontWeight: '900',
            textTransform: 'uppercase',
            letterSpacing: 1
          }
        }}
      >
        <Tab.Screen 
          name="ScannerTab" 
          component={ScannerStack} 
          options={{
            title: 'Scanner',
            tabBarIcon: ({ color, size }) => <BrainCircuit color={color} size={size} />
          }}
        />
        <Tab.Screen 
          name="Insights" 
          component={AnalyticsScreen} 
          options={{
            title: 'Insights',
            headerShown: true,
            headerStyle: { backgroundColor: '#0B0F19' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontWeight: '900', letterSpacing: -0.5 },
            headerShadowVisible: false,
            tabBarIcon: ({ color, size }) => <BarChart3 color={color} size={size} />
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
